Configuration TMRolesDotNet
{
  param ($MachineName)

  Node $MachineName
  {
    #Install .NET 3.5
    WindowsFeature NET-Framework-Features
    {
      Ensure = "Present"
      Name = "NET-Framework-Features"
    }

    #Install .NET 4.5
    WindowsFeature NET-Framework-45-Features
    {
      Ensure = "Present"
      Name = "NET-Framework-45-Features"
    }
  }
} 
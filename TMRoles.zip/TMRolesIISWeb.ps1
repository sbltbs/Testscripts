Configuration TMRolesIISWeb
{
  param ($MachineName)

  Node $MachineName
  {
    #Install the IIS Role
    WindowsFeature IIS
    {
      Ensure = "Present"
      Name = "Web-Server"
    }
     WindowsFeature WebServerManagementConsole
    {
        Name = "Web-Mgmt-Console"
        Ensure = "Present"
    }
     WindowsFeature Web-Mgmt-Service
    {
        Name = "Web-Mgmt-Service"
        Ensure = "Present"
    }
     WindowsFeature Web-Mgmt-Tools
    {
        Name = "Web-Mgmt-Tools"
        Ensure = "Present"
    }
     WindowsFeature Web-Mgmt-Compat
    {
        Name = "Web-Mgmt-Compat"
        Ensure = "Present"
    }
     WindowsFeature Web-Metabase
    {
        Name = "Web-Metabase"
        Ensure = "Present"
    }
     WindowsFeature TCPPortSharing
    {
        Name = "NET-WCF-TCP-PortSharing45"
        Ensure = "Present"
    }
     WindowsFeature Web-Default-Doc
    {
        Name = "Web-Default-Doc"
        Ensure = "Present"
    }
     WindowsFeature Web-Dir-Browsing
    {
        Name = "Web-Dir-Browsing"
        Ensure = "Present"
    }

     WindowsFeature Web-Http-Errors
    {
        Name = "Web-Http-Errors"
        Ensure = "Present"
    }
     WindowsFeature Web-Static-Content
    {
        Name = "Web-Static-Content"
        Ensure = "Present"
    }
     WindowsFeature Web-Http-Redirect
    {
        Name = "Web-Http-Redirect"
        Ensure = "Present"
    }
     WindowsFeature Web-DAV-Publishing
    {
        Name = "Web-DAV-Publishing"
        Ensure = "Present"
    }
     WindowsFeature Web-Health
    {
        Name = "Web-Health"
        Ensure = "Present"
    }
     WindowsFeature Web-Http-Logging
    {
        Name = "Web-Http-Logging"
        Ensure = "Present"
    }
     WindowsFeature Web-Custom-Logging
    {
        Name = "Web-Custom-Logging"
        Ensure = "Present"
    }
     WindowsFeature Web-Log-Libraries
    {
        Name = "Web-Log-Libraries"
        Ensure = "Present"
    }
     WindowsFeature Web-ODBC-Logging
    {
        Name = "Web-ODBC-Logging"
        Ensure = "Present"
    }
     WindowsFeature Web-Request-Monitor
    {
        Name = "Web-Request-Monitor"
        Ensure = "Present"
    }
     WindowsFeature Web-Http-Tracing
    {
        Name = "Web-Http-Tracing"
        Ensure = "Present"
    }
     WindowsFeature Web-Performance
    {
        Name = "Web-Performance"
        Ensure = "Present"
    }
     WindowsFeature Web-Stat-Compression
    {
        Name = "Web-Stat-Compression"
        Ensure = "Present"
    }
     WindowsFeature Web-Dyn-Compression
    {
        Name = "Web-Dyn-Compression"
        Ensure = "Present"
    }
     WindowsFeature Web-Security
    {
        Name = "Web-Security"
        Ensure = "Present"
    }
     WindowsFeature Web-Filtering
    {
        Name = "Web-Filtering"
        Ensure = "Present"
    }
     WindowsFeature Web-Basic-Auth
    {
        Name = "Web-Basic-Auth"
        Ensure = "Present"
    }
     WindowsFeature Web-CertProvider
    {
        Name = "Web-CertProvider"
        Ensure = "Present"
    }
     WindowsFeature Web-Client-Auth
    {
        Name = "Web-Client-Auth"
        Ensure = "Present"
    }
     WindowsFeature Web-Digest-Auth
    {
        Name = "Web-Digest-Auth"
        Ensure = "Present"
    }
     WindowsFeature Web-Cert-Auth
    {
        Name = "Web-Cert-Auth"
        Ensure = "Present"
    }
     WindowsFeature Web-IP-Security
    {
        Name = "Web-IP-Security"
        Ensure = "Present"
    }
     WindowsFeature Web-Url-Auth
    {
        Name = "Web-Url-Auth"
        Ensure = "Present"
    }
     WindowsFeature Web-Windows-Auth
    {
        Name = "Web-Windows-Auth"
        Ensure = "Present"
    }
     WindowsFeature Web-App-Dev
    {
        Name = "Web-App-Dev"
        Ensure = "Present"
    }
     WindowsFeature Web-Net-Ext
    {
        Name = "Web-Net-Ext"
        Ensure = "Present"
    }
     WindowsFeature Web-Net-Ext45
    {
        Name = "Web-Net-Ext45"
        Ensure = "Present"
    }
     WindowsFeature Web-AppInit
    {
        Name = "Web-AppInit"
        Ensure = "Present"
    }
     WindowsFeature Web-ASP
    {
        Name = "Web-ASP"
        Ensure = "Present"
    }
     WindowsFeature Web-Asp-Net
    {
        Name = "Web-Asp-Net"
        Ensure = "Present"
    }
     WindowsFeature Web-Asp-Net45
    {
        Name = "Web-Asp-Net45"
        Ensure = "Present"
    }
     WindowsFeature Web-CGI
    {
        Name = "Web-CGI"
        Ensure = "Present"
    }
     WindowsFeature Web-ISAPI-Ext
    {
        Name = "Web-ISAPI-Ext"
        Ensure = "Present"
    }
     WindowsFeature Web-ISAPI-Filter
    {
        Name = "Web-ISAPI-Ext"
        Ensure = "Present"
    }
     WindowsFeature Web-Includes
    {
        Name = "Web-Includes"
        Ensure = "Present"
    }
     WindowsFeature Web-WebSockets
    {
        Name = "Web-WebSockets"
        Ensure = "Present"
    }
  }
} 